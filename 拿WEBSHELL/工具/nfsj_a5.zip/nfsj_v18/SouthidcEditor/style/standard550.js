config.FixWidth = "";
config.UploadUrl = "uploadfile/";
config.InitMode = "EDIT";
config.AutoDetectPasteFromWord = "1";
config.BaseUrl = "1";
config.BaseHref = "";
config.AutoRemote = "1";
config.ShowBorder = "0";
config.StateFlag = "1";
config.SBCode = "1";
config.SBEdit = "1";
config.SBText = "1";
config.SBView = "1";
config.EnterMode = "1";
config.Skin = "office2003";
config.AllowBrowse = "1";
config.AllowImageSize = "100";
config.AllowFlashSize = "100";
config.AllowMediaSize = "100";
config.AllowFileSize = "500";
config.AllowRemoteSize = "100";
config.AllowLocalSize = "100";
config.AllowImageExt = "gif|jpg|jpeg|bmp";
config.AllowFlashExt = "swf";
config.AllowMediaExt = "rm|mp3|wav|mid|midi|ra|avi|mpg|mpeg|asf|asx|wma|mov";
config.AllowFileExt = "rar|zip|pdf|doc|xls|ppt|chm|hlp";
config.AllowRemoteExt = "gif|jpg|bmp";
config.AreaCssMode = "0";
config.SYWZFlag = "0";
config.SYTPFlag = "0";
config.ServerExt = "asp";

config.Toolbars = [
	["TBHandle", "FormatBlock", "FontName", "FontSize", "Bold", "Italic", "UnderLine", "StrikeThrough", "TBSep", "SuperScript", "SubScript", "UpperCase", "LowerCase", "TBSep", "JustifyLeft", "JustifyCenter", "JustifyRight", "JustifyFull"],
	["TBHandle", "Cut", "Copy", "Paste", "PasteText", "FindReplace", "Delete", "RemoveFormat", "TBSep", "UnDo", "ReDo", "SelectAll", "UnSelect", "TBSep", "OrderedList", "UnOrderedList", "Indent", "Outdent", "ParagraphAttr", "TBSep", "ForeColor", "BackColor", "BgColor", "BackImage", "TBSep", "RemoteUpload", "LocalUpload", "ImportWord", "ImportExcel"],
	["TBHandle", "Image", "Flash", "Media", "File", "GalleryMenu", "TBSep", "TableMenu", "FormMenu", "TBSep", "Fieldset", "Iframe", "HorizontalRule", "Marquee", "CreateLink", "Unlink", "Map", "Anchor", "TBSep", "Template", "Symbol", "Emot", "Art", "Excel", "Quote", "ShowBorders", "TBSep", "Maximize", "About"]
];
