<!DOCTYPE html>
<html lang="zh-CN">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>商城公告</title>
    <!-- Bootstrap core CSS -->
    <link href="//cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">

    <style media="screen">
        .page-header {
            text-align: center;
        }
        img {
            width: 100%;
        }
    </style>

  </head>
  <body>
    <!-- Begin page content -->
    <div class="container" style="width:95%">
      <p class="lead"><?=$notice['content']?></p>
    </div>
  </body>
</html>
