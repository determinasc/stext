<?php

namespace App\Models\v2;

use App\Models\BaseModel;
use App\Helper\Token;

class Coupon extends BaseModel {

}
