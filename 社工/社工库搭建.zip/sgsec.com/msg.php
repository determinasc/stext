﻿<?php if(!defined('IN_TM')){exit('Access Denied');}?>

﻿<!DOCTYPE html>
<html>
    <head>
	    <meta charset="utf-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	    <title>社工库查询</title>
	    <meta name="description" content="免费社工库">
	    <meta name="keywords" content="社工库查询-免费社工库">
	    <link rel="icon" href="http://runing.cdn.duapp.com/style/favicon.ico" type="image/x-icon" />
	    <link href="http://runing.cdn.duapp.com/style/dist/css/bootstrap.css" rel="stylesheet">
	    <link href="http://runing.cdn.duapp.com/style/style.css" rel="stylesheet">
	    <script src="http://runing.cdn.duapp.com/style/jquery.js"></script>
	    <script src="http://runing.cdn.duapp.com/style/template.js"></script>
	    <script src="http://runing.cdn.duapp.com/style/dist/js/bootstrap.min.js"></script>
		
		<script type="text/javascript" src="jBox/jquery-1.4.2.min.js"></script>
  <script type="text/javascript" src="jBox/jquery.jBox-2.3.min.js"></script>
  <script type="text/javascript" src="jBox/i18n/jquery.jBox-zh-CN.js"></script>
  <link type="text/css" rel="stylesheet" href="jBox/Skins/Blue/jbox.css"/>
		</head>

<div class="jumbotron" style="margin:0 auto;TEXT-ALIGN: center;">
        <p><?php echo $msg;?></p>
        <p><a class="btn btn-danger btn-lg" href="/<?php echo $url;?>">点击继续</a>&nbsp;&nbsp;&nbsp;<a class="btn btn-primary btn-lg" role="button" href="javascript:history.go(-1);">向上一页</a></p>
      </div>
	  
	  
