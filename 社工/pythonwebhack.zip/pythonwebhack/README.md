# pythonwebhack

> 用python 2.7实现的web框架建立的在线渗透平台
> web框架是flask  前端框架是amazeUI

## 安装
`pip install flask`  

`pip install requests`  

`pip install MySQLdb  `  


[usage]: python `myweb.py `

乌云数据库文件安装 链接: http://pan.baidu.com/s/1hrKYy8W 密码: yrrr

## 更新

- 12.7 更新 加入乌云漏洞库忽略漏洞查询
- 11.22 更新 集成了乌云漏洞查询 [搭建教程][3]
- 11.7 更新 加入了在线社工库 调用的接口~
- 10.25 更新 加入了社会工程学密码生成和whois查询
- 10.21 更新 加入了CMS在线识别


## 学习教程
每一步都记录了 [编写记录][1]


  用新浪云搭建了下 [http://systeminfo.applinzi.com/][2]


  [1]: http://bbs.ichunqiu.com/forum.php?mod=collection&action=view&ctid=65
  [2]: http://systeminfo.applinzi.com/
  [3]: http://bbs.ichunqiu.com/forum.php?mod=viewthread&tid=15744&page=1&extra=#pid261144
